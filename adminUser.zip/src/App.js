import React, { useState, useCallback } from 'react';
import {BrowserRouter as Router, Redirect, Route, Switch } from "react-router-dom";

import MainNavigation from './shared/components/Navigation/MainNavigation.js';
import MainPage from "./MainPage/MainPage.js";
import UserSignUp from "./MainPage/userSignUp";
import UserLogin from "./MainPage/userLogin";
import UsersTickets from './tickets/pages/UsersTickets.js';
import UpdateTicket from './tickets/pages/UpdateTicket.js';
import { AuthContext } from './shared/context/auth-context.js';
import { useAuth } from './shared/hooks/auth-hook';

const App = () => {
  const {token, login, logout, userId} = useAuth();

  let routes;

  if (token) {
    routes = (
      <Switch>
        <Route path="/" exact>
          <MainPage />
        </Route>
        <Route path="/:userId/tickets" >
          <UsersTickets />
        </Route>
        <Route path="/ticket/:ticketId" >
          <UpdateTicket />
        </Route>
        <Redirect to="/" />
      </Switch>
    );
  } else {
    routes = (
      <Switch>
        <Route path="/" exact>
          <MainPage />
        </Route>
        <Route path="/signup">
          <UserSignUp />
        </Route>
        <Route path="/login">
          <UserLogin />
        </Route>
        <Redirect to="/" />
      </Switch>
    );
  }

  return (
    <AuthContext.Provider value={{isLoggedIn: !!token, token:token, userId: userId, login: login, logout: logout}}>
      <Router>
       <MainNavigation />
      <main>
        {routes}
      </main>
      </Router>   
    </AuthContext.Provider>
  );
};

export default App;