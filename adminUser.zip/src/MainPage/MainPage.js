import React, { useContext } from 'react';

import { AuthContext } from '../shared/context/auth-context';
import Button from '../shared/components/FormElements/Button';
import Image from '../shared/components/UIElements/Logo';
import './mainPage.css';

const MainPage = () => {
  const auth = useContext(AuthContext);

  return (
    <div className="main-container-1 row" >
        <div className='left-container col-lg-6'>
          <h1>Complaint Ticket Generation System</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          {!auth.isLoggedIn && (<Button main to={`/signup`} >Sign Up</Button>)} 
        </div>
        <div className='right-container col-lg-6'>
        <Image 
        image={'../../images/IconBros2.jpg'}
        alt={'logo.png'}  
        />
        </div>  
    </div> 
  );
};

export default MainPage;