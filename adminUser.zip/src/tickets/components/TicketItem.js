import React, { useState } from 'react';

import Card from '../../shared/components/UIElements/Card';
import Button from '../../shared/components/FormElements/Button';
import Modal from '../../shared/components/UIElements/Modal';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import { useHttpClient } from '../../shared/hooks/http-hook';
import './TicketItem.css';

const TicketItem = props => {
  const { isLoading, error, sendRequest, clearError} = useHttpClient();
  const [showStatus, setShowStatus] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const openStausHandler = () => setShowStatus(true);

  const closeStatusHandler = () => setShowStatus(false);

  const showDeleteWarningHandler = () => {
    setShowConfirmModal(true);
  };

  const cancelDeleteHandler = () => {
    setShowConfirmModal(false);
  };

  const confirmDeleteHandler = async () => {
    setShowConfirmModal(false);
    console.log("Deleting...");
    try {
       await sendRequest(`http://localhost:5000/api/tickets/${props.id}`,
       'DELETE',
        {
          'Content-type': 'application/json'
        }
       );
       props.onDelete(props.id);
     } catch (err) {}
  };

  return (
    <React.Fragment>
    <ErrorModal error={error} onClear={clearError}/>
      <Modal
        show={showStatus}
        onCancel={closeStatusHandler}
        header={props.issue}
        contentClass="ticket-item__modal-content-1"
        footerClass="ticket-item__modal-actions"
        footer={<Button onClick={closeStatusHandler}>CLOSE</Button>}
      >
        <div className="ticket-item__status" >
          <p><span>Description:  </span>{props.description}</p>
          <p><span>Status:  </span>{props.status}</p>
          <p><span>Ticket ID:  </span>{props.id}</p>
          <p><span>Creator ID:  </span>{props.creatorId}</p>
        </div>
      </Modal>
      <Modal
        show={showConfirmModal}
        onCancel={cancelDeleteHandler}
        header="Are you sure?"
        footerClass="ticket-item__modal-actions"
        footer={
          <React.Fragment>
            <Button inverse onClick={cancelDeleteHandler}>
              CANCEL
            </Button>
            <Button danger onClick={confirmDeleteHandler}>
              DELETE
            </Button>
          </React.Fragment>
        }
      >
        <p>
          Do you want to proceed and delete this place? Please note that it
          can't be undone thereafter.
        </p>
      </Modal>

      <li className="ticket-item">
        <Card className="ticket-item__content">
        {isLoading && <LoadingSpinner asOverlay/>}
          <div className="ticket-item__border">
            <div className="ticket-item__info">
              <h2>{props.issue}</h2>
              <h3>{props.description}</h3>
            </div>
            <div className="ticket-item__actions">
              <Button inverse onClick={openStausHandler}>VIEW </Button>
              <Button to={`/ticket/${props.id}`}>EDIT </Button>
              <Button danger onClick={showDeleteWarningHandler}>DELETE </Button>
            </div>
          </div>
        </Card>
      </li>
    </React.Fragment>
  );
};

export default TicketItem;