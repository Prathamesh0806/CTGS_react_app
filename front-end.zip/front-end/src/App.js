import React from 'react';
import {BrowserRouter as Router, Redirect, Route, Switch } from "react-router-dom";

import MainNavigation from './shared/components/Navigation/MainNavigation.js';
import Users from "./users/pages/Users.js";
import MainPage from "./MainPage/MainPage.js";
import AdminSignup from "./MainPage/adminSignUp";
import AdminLogin from "./MainPage/adminLogin";
import UsersTickets from './tickets/pages/UsersTickets.js';
import ResolvedTickets from './tickets/pages/ResolvedTickets.js';
import PendingTickets from './tickets/pages/PendingTickets.js';
import UpdateTicket from './tickets/pages/UpdateTicket.js';
import Dashboard from './Admins/pages/viwePages/dashboard.js';
import AdminUsersTickets from './tickets/pages/adminUserTickets'
import { AuthContext } from './shared/context/auth-context.js';
import { useAuth } from './shared/hooks/auth-hook';

const App = () => {
  const {token, login, logout, adminId} = useAuth();

  let routes;

  if (token) {
    routes = (
      <Switch>
        <Route path="/" exact>
          <MainPage />
        </Route>
        <Route path="/user" exact>
          <Users />
        </Route>
        <Route path="/dashboard" exact>
          <Dashboard />
        </Route>
        <Route path="/tickets" >
          <UsersTickets />
        </Route>
        <Route path="/resolved/tickets" >
          <ResolvedTickets />
        </Route>
        <Route path="/pending/tickets" >
          <PendingTickets />
        </Route>
        <Route path="/:userId/tickets" >
          <AdminUsersTickets />
        </Route>
        <Route path="/ticket/:ticketId" >
          <UpdateTicket />
        </Route>
        <Redirect to="/" />
      </Switch>
    );
  } else {
    routes = (
      <Switch>
        <Route path="/" exact>
          <MainPage />
        </Route>
        <Route path="/adminSignUp">
          <AdminSignup />
        </Route>
        <Route path="/adminLogIn">
          <AdminLogin/>
        </Route>
        <Redirect to="/" />
      </Switch>
    );
  }

  return (
    <AuthContext.Provider value={{isLoggedIn: !!token, token:token, adminId: adminId , login: login, logout: logout}}>
      <Router>
       <MainNavigation />
      <main>
        {routes}
      </main>
      </Router>   
    </AuthContext.Provider>
  );
};

export default App;