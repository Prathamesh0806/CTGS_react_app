import React, {useState, useEffect} from 'react';
import { useParams} from 'react-router-dom';

import Card from '../../../shared/components/UIElements/Card';
import Avatar from '../../../shared/components/UIElements/Avatar';
import ErrorModal from '../../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../../shared/components/UIElements/LoadingSpinner';
import { useHttpClient } from '../../../shared/hooks/http-hook';

import './profile.css';
// import UserItem from '../../../users/components/UserItem';

const Profile = () => {
    const [loadedAdmin, setLoadedAdmin] = useState();
    const {isLoading, error, sendRequest, clearError} = useHttpClient();

    const adminId = useParams().adminId;

    console.log(adminId);

    useEffect(() => {
    const fetchUsers =async () => {
      try {
        const responseData = await sendRequest(`http://localhost:5000/api/admin/profile/${adminId}` 
        );
        setLoadedAdmin(responseData.email, responseData.name, responseData.role);
      
      } catch (err) {
          
      }
    };

    fetchUsers();
    },[sendRequest, adminId]);

    // const ticketDeletedHandeler = (deletedTicket) => {
    //   setLoadedTickets(prevTickets =>prevTickets.filter(ticket => ticket.id !== deletedTicket));
    // }

    

    const items = loadedAdmin;
    console.log(items);
   

  return (
    <div className="profile-container">
    <ErrorModal error={error} onClear={clearError} />
        <Card className="profile-item">
        {isLoading && <LoadingSpinner asOverlay/>}
            <Avatar 
               image='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMVe0WsA4xBzb-5oLoBhzcug0R4bBuF9nPTw&usqp=CAU'
               alt='demon salvator'
               width='40%'
               height='40%'
            />
            <h4>Admin</h4>
            <div>
                <span className='profile-lable'>Admin Name:</span>
                {/* <span className='profile-input'>{items.name}</span> */}
            </div>
            <div>
                <span className='profile-lable'>Email Id:</span>
                {/* <span className='profile-input'>{items.email}</span> */}
            </div>
            <div>
                <span className='profile-lable'>Role:</span>
                {/* <span className='profile-input'>{items.role}</span> */}
            </div>
        </Card>
    </div>
  )
}

export default Profile;