import React from 'react';
import {Chart, Tooltip, Title, ArcElement, Legend} from 'chart.js';
import { Pie} from 'react-chartjs-2';

import Card from '../../../shared/components/UIElements/Card';

import './piChart.css';

Chart.register(
    Tooltip, Title, ArcElement, Legend 
);


// const data = {

//     datasets: [{
//         data: [ 20, 30],
//         backgroundColor: [
//             '#2F8F9D',
//             '#F73D93'
//         ]}
//     ],

//     // These labels appear in the legend and in the tooltips when hovering different arcs 
//     labels: [
//         'Total Tickets',
//         'Resolved Tickets',
        
//     ] 
// };

const piChart = props => {
  return (
    <div className="Chart-container">
        <Card className="chart-item">
            <Pie data={props.data}/>
        </Card>
    </div>
  )
}

export default piChart;