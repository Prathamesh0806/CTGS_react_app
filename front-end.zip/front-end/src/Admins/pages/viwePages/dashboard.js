import React, {useState, useEffect} from 'react';
import { NavLink } from 'react-router-dom';

import MarkunreadMailboxIcon from '@mui/icons-material/MarkunreadMailbox';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import GroupIcon from '@mui/icons-material/Group';
import PersonIcon from '@mui/icons-material/Person';
import PieChart from './piChart';
import {useHttpClient} from '../../../shared/hooks/http-hook';
import './dashboard.css';

const Dashboard = () => {

    const [loadedTickets, setLoadedTickets] = useState();
    const [resolvedTickets, setResolvedTickets] = useState();
    const [pendingTickets, setPendingTickets] = useState();
    const [loadedUsers, setLoadedUsers] = useState();
    const { sendRequest} = useHttpClient();

    // const adminId = useParams().adminId;

    useEffect(() => {
    const fetchTickets =async () => {
      try {
        const responseData = await sendRequest(`http://localhost:5000/api/tickets/alltickets` 
        );
        setLoadedTickets(responseData.tickets.length);
      } catch (err) {
          
      }
    };

    fetchTickets();
    }, [sendRequest]);

    useEffect(() => {
        const fetchTickets =async () => {
          try {
            const responseData = await sendRequest(`http://localhost:5000/api/tickets/resolvedtickets` 
            );
            setResolvedTickets(responseData.tickets.length);
          } catch (err) {
              
          }
        };
    
        fetchTickets();
    }, [sendRequest]);

    useEffect(() => {
        const fetchTickets =async () => {
          try {
            const responseData = await sendRequest(`http://localhost:5000/api/tickets/pendingtickets` 
            );
            setPendingTickets(responseData.tickets.length);
          } catch (err) {
              
          }
        };
    
        fetchTickets();
    }, [sendRequest]);

    useEffect(() => {
      const fetchUsers = async () => {
        try {
          const responseData = await sendRequest(
            `http://localhost:5000/api/adminUser/user`
          );
  
          setLoadedUsers(responseData.users.length);
        } catch (err) {}
      };
      fetchUsers();
    }, [sendRequest]);


    const ticketCount = loadedTickets;
    // console.log(ticketCount);
    const resolvedTicketCount = resolvedTickets;
    // console.log(resolvedTicketCount);
    const pendingTicketsCount = pendingTickets;
    const totalUserCount = loadedUsers;

    const data = {

        datasets: [{
            data: [ ticketCount, resolvedTicketCount, pendingTicketsCount],
            backgroundColor: [
                '#2F8F9D',
                '#F73D93',
                '#FF4949'
            ]}
        ],
    
        // These labels appear in the legend and in the tooltips when hovering different arcs 
        labels: [
            'Total Tickets',
            'Resolved Tickets',
            'Pending Tickets'
            
        ] 
    };
 
  return (
    <div>
        <div className="dashboard-container">
            <div className="dashboard-item">
                <span className="dashboard-content">{ticketCount || 0}</span>
                <span className="dashboard-icon">
                <MarkunreadMailboxIcon className="featuredIcon"  sx={{ fontSize: 60}}/>
                </span>
                <h3><NavLink to="/tickets" className="dashboard-link">Total Tickets</NavLink></h3>
            </div>
        
            <div className="dashboard-item">
                <span className="dashboard-content">{resolvedTicketCount || 0}</span>
                <span className="dashboard-icon">
                <CheckBoxIcon className="featuredIcon" sx={{ fontSize: 60 }}/>
                </span>
                <h3><NavLink to="/resolved/tickets" className="dashboard-link">Resolved Tickets</NavLink></h3>
            </div>

            <div className="dashboard-item">
                <span className="dashboard-content">{pendingTicketsCount || 0}</span>
                <span className="dashboard-icon">
                <PersonIcon className="featuredIcon" sx={{ fontSize: 60 }}/>
                </span>
                <h3><NavLink to="/pending/tickets" className="dashboard-link">Pending Tickets</NavLink></h3>
            </div>
        
            <div className="dashboard-item">
                <span className="dashboard-content">{totalUserCount || 0}</span>
                <span className="dashboard-icon">
                <GroupIcon className="featuredIcon" sx={{ fontSize: 60 }} />
                </span>
                <h3><NavLink to="/user" className="dashboard-link">Users</NavLink></h3>
            </div>
        
           
        </div>
        <div>
            <PieChart data={data}/>
        </div>
    </div>
  );
};

export default Dashboard;