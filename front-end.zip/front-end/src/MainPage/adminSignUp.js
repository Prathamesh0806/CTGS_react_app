import React, {useContext} from 'react';
import { useHistory } from 'react-router-dom';

import Card from '../shared/components/UIElements/Card';
import Button from '../shared/components/FormElements/Button';
import Input from '../shared/components/FormElements/Input';
import ErrorModal from '../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../shared/components/UIElements/LoadingSpinner';
import {VALIDATOR_EMAIL, VALIDATOR_MINLENGTH, VALIDATOR_REQUIRE} from '../shared/util/validators';
import {useForm} from '../shared/hooks/form-hook';
import { AuthContext } from '../shared/context/auth-context';
import { useHttpClient } from '../shared/hooks/http-hook';
import './adminSignUp.css';

const AdminSignUp = () => {
  const auth = useContext(AuthContext);
  const {isLoading, error, sendRequest, clearError} = useHttpClient();
  const history = useHistory();

  const [formState, inputHandler]  = useForm ({
    name: {
      value: '',
      isvalid: false
    },
    email: {
      value:'',
      isValid: false
    },
    password: {
      value:'',
      isValid: false
    },
    role: {
      value:'',
      isValid: false
    }
  },false);

  const signUpSubmitHandler = async event => {
    event.preventDefault();
    try {  
      const responseData = await sendRequest('http://localhost:5000/api/admin/signup', 
        'POST',
        JSON.stringify({
          name: formState.inputs.name.value,
          email: formState.inputs.email.value,
          password: formState.inputs.password.value,
          role: formState.inputs.role.value
        }),
        {
          'Content-type' : 'application/json'
        }
      );
      history.push('/');
      auth.login(responseData.userId, responseData.token);
    } catch (err) {}
  }

  return (
    <div className="main-container">
     <ErrorModal error={error} onClear={clearError}/>
      <Card  className="authentication">
        {isLoading && <LoadingSpinner asOverlay/>}
        <h2>Sign Up</h2>
        <hr/>
        <form onSubmit={signUpSubmitHandler}>
            <Input 
              element="input" 
              id="name" 
              type="text" 
              label="Your Name" 
              validators={[VALIDATOR_REQUIRE()]}  
              errorText="Please enter the valide name."
              onInput={inputHandler}
            /> 
            <Input 
              element="input" 
              id="email" 
              type="email" 
              label="E-Mail" 
              validators={[VALIDATOR_EMAIL()]}  
              errorText="Please enter the valide email address."
              onInput={inputHandler}
            /> 
            <Input 
              element="input" 
              id="password"
              type="password" 
              label="Password" 
              validators={[VALIDATOR_MINLENGTH(6)]}  
              errorText="Please enter a valid password, at least 6 characters long." 
              onInput={inputHandler}
            /> 
            <Input 
              element="input" 
              id="role" 
              type="text" 
              label="Role" 
              validators={[VALIDATOR_REQUIRE()]}  
              errorText="Please enter the valide role."
              onInput={inputHandler}
            /> 
            <Button type="submit" disabled= {!formState.isValid} >SIGN UP</Button>                 
        </form>    
      </Card>
    </div>
  );
}

export default AdminSignUp;