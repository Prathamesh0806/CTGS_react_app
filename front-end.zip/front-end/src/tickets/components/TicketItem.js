import React, { useState, useContext } from 'react';

import Card from '../../shared/components/UIElements/Card';
import Button from '../../shared/components/FormElements/Button';
import Modal from '../../shared/components/UIElements/Modal';
import {AuthContext} from '../../shared/context/auth-context';
import './TicketItem.css';

const TicketItem = props => {
  const auth = useContext(AuthContext);
  const [showStatus, setShowStatus] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const openStausHandler = () => setShowStatus(true);

  const closeStatusHandler = () => setShowStatus(false);

  const showDeleteWarningHandler = () => {
    setShowConfirmModal(true);
  };

  const cancelDeleteHandler = () => {
    setShowConfirmModal(false);
  };

  const confirmDeleteHandler = async () => {
    setShowConfirmModal(false);
    console.log("Deleting...");
    // try {
    //   await sendRequest(
    //     process.env.REACT_APP_BACKEND_URL+`/places/${props.id}`,
    //     'DELETE',
    //     null,
    //     {
    //       Authorization: 'Bearer' + auth.token
    //     }
    //   );
    //   props.onDelete(props.id);
    // } catch (err) {}
  };

  // const buttonLoad = props.status;
  // console.log(buttonLoad);

  const btnStatus = props.adnUser;
  console.log(btnStatus);
  return (
    <React.Fragment>
      <Modal
        show={showStatus}
        onCancel={closeStatusHandler}
        header={props.issue}
        contentClass="ticket-item__modal-content-1"
        footerClass="ticket-item__modal-actions"
        footer={<Button onClick={closeStatusHandler}>CLOSE</Button>}
      >
        <div className="ticket-item__status" >
          <p><span>Description:  </span>{props.description}</p>
          <p><span>Status:  </span>Resolved</p>
          <p><span>Ticket ID:  </span>{props.id}</p>
        </div>
      </Modal>
      <Modal
        show={showConfirmModal}
        onCancel={cancelDeleteHandler}
        header="Are you sure?"
        footerClass="ticket-item__modal-actions"
        footer={
          <React.Fragment>
            <Button inverse onClick={cancelDeleteHandler}>
              CANCEL
            </Button>
            <Button danger onClick={confirmDeleteHandler}>
              DELETE
            </Button>
          </React.Fragment>
        }
      >
        <p>
          Do you want to proceed and delete this place? Please note that it
          can't be undone thereafter.
        </p>
      </Modal>

      <li className="ticket-item">
        <Card className="ticket-item__content">
          <div className="ticket-item__border">
            <div className="ticket-item__info">
              <h2>{props.issue}</h2>
              <h3>{props.description}</h3>
            </div>
            <div className="ticket-item__actions">
              {/* <Button inverse onClick={openStausHandler}>VIEW </Button> */}
              <Button to={`/ticket/${props.id}`}>EDIT </Button>
              {/* <Button danger onClick={showDeleteWarningHandler}>DELETE </Button> */}
            </div>
          </div>
        </Card>
      </li>
    </React.Fragment>
  );
};

export default TicketItem;