import React, { useEffect, useState, useContext } from 'react';
import { useParams, useHistory} from 'react-router-dom';

import Input from '../../shared/components/FormElements/Input';
import Button from '../../shared/components/FormElements/Button';
import Card from '../../shared/components/UIElements/Card';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import {useForm} from '../../shared/hooks/form-hook';
import {useHttpClient} from '../../shared/hooks/http-hook';
import { AuthContext } from '../../shared/context/auth-context';
import { VALIDATOR_MINLENGTH, VALIDATOR_REQUIRE } from '../../shared/util/validators';
import './UpdateTicket.css';



const NewTicket = props => {
    const auth = useContext(AuthContext);
    const [loadedTickets, setLoadedTickets] = useState();
    const {isLoading, error, sendRequest, clearError} = useHttpClient();
    const ticketId = useParams().ticketId;
    const history = useHistory();

    const [formState, inputHandler, setFormData] = useForm(
        {
          issue: {
            value: '',
            isValid: false
          },
          description: {
            value: '',
            isValid: false
          },
          status: {
            value:'',
            isValid: false 
          }
        },
        false
    );

    useEffect(() => {
        const fetchTicket =async () => {
          try {
            const responseData = await sendRequest(`http://localhost:5000/api/tickets/${ticketId}` 
            );
            console.log(responseData.ticket);
            setLoadedTickets(responseData.ticket);
            setFormData(
                {
                issue: {
                    value: responseData.ticket.issue,
                    isValid: true
                },
                description: {
                    value: responseData.ticket.description,
                    isValid: true
                },
                status: {
                    value:'',
                    isValid: true 
                }
                },
                true
            );
          } catch (err) {
              
          }
        };
    
        fetchTicket();
        }, [sendRequest, ticketId, setFormData]);
    console.log();
   
    const ticketSubmitHandler = async event => {
        event.preventDefault();
        console.log(formState);
        try {
            await sendRequest(`http://localhost:5000/api/tickets/asign/${ticketId}`,
                'POST',
                JSON.stringify({
                    issue: formState.inputs.issue.value,
                    description: formState.inputs.description.value,
                    status: formState.inputs.status.value
                }),
                {
                    'Content-Type': 'application/json'
                }
            );
            history.push(`/${auth.userId}/tickets`);
        } catch (err) {
            
        }
    };

    if (isLoading) {
        return (
          <div className="center">
            <h1><LoadingSpinner /></h1>
          </div>
        );
    }

    if (!loadedTickets && !error) {
        return  <div className="center main">
          <Card >
              <h3>Could not found ticket</h3>
          </Card>
        </div>;
    }
    
  return (
    <div>
    <ErrorModal error={error} onClear={clearError} />
        <form className="place-form" onSubmit={ticketSubmitHandler}>
            <Input
                id="issue"
                element="input"
                type="text"
                label="Issue"
                validators={[VALIDATOR_REQUIRE()]}
                errorText="Please enter a valid issue."
                onInput={inputHandler}
                initialValue={ loadedTickets.issue }
                initialValid={ true}
                desabled={true}
            />
            <Input
                id="description"
                element="textarea"
                label="Description"
                validators={[VALIDATOR_MINLENGTH(5)]}
                errorText="Please enter a valid description at lest 5 characters."
                onInput={inputHandler}
                initialValue={ loadedTickets.description }
                initialValid={ true}
                disabled={true}
            />
            <Input
                id="status"
                element="input"
                type="text"
                label="Asign To"
                validators={[VALIDATOR_REQUIRE()]}
                onInput={inputHandler}
                // initialValue={ formState.inputs.description.value }
                // initialValid={ formState.inputs.description.isValid }
            />
            <Button type="submit" disabled={!formState.isValid}>UPDATE TICKET</Button>
        </form>
    </div>
  );
}

export default NewTicket;






// import React from 'react';

// import Input from '../../shared/components/FormElements/Input';
// import { VALIDATOR_REQUIRE, VALIDATOR_MINLENGTH } from '../../shared/util/validators';
// import {useForm }from '../../shared/hooks/form-hook';
// import Button from '../../shared/components/FormElements/Button';
// import './NewTicket.css';

// const NewTicket = () => {
//   const [formState, inputHandler]  = useForm ({
//     issue: {
//       value:'',
//       isValid: false
//     },
//     description: {
//       value:'',
//       isValid: false
//     }
//   },false)
 
//   const ticketSubmitHandler = event => {
//     event.preventDefault();
//     console.log(formState.inputs);
//   };

//   return (
//     <form className="ticket-form" onSubmit={ticketSubmitHandler}>
//         <Input 
//           id="issue"
//           element="input"
//           type="text"
//           label="Issue"
//           validators={[VALIDATOR_REQUIRE()]}
//           errorText="Please enter a valid title."
//           onInput={inputHandler}
//         />
//         <Input 
//           id="description"
//           element="textarea"
//           label="Description"
//           validators={[VALIDATOR_MINLENGTH(5)]}
//           errorText="Please enter a valid description (at least 5 character)."
//           onInput={inputHandler}
//         />
//  <Button type="submit" disabled= {!formState.isValid} >ADD TICKET</Button> 
//     </form>
//   );
// }

// export default NewTicket;