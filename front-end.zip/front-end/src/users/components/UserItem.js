import React from 'react';
import { Link } from 'react-router-dom';

import Avatar from '../../shared/components/UIElements/Avatar';
import Card from '../../shared/components/UIElements/Card';
import './UserItem.css';
import Button from '../../shared/components/FormElements/Button'; 

const UserItem = props => {
  return (
    <li className="user-item">
      <Card className="user-item__content">
        <Link to={`/${props.id}/tickets`}>
          <div className="user-item__image">
            <Avatar image={'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMVe0WsA4xBzb-5oLoBhzcug0R4bBuF9nPTw&usqp=CAU'} alt={props.name} />
          </div>
          <div className="user-item__info">
            <h2>{props.name}</h2>
            {/* <h3>{props.role}</h3> */}
            <h3>
              {props.ticketCount} {props.ticketCount === 1 ? 'Ticket' : 'Tickets'}
            </h3>
           
          </div>
        </Link>
      </Card>
    </li>
  );
};

export default UserItem;
