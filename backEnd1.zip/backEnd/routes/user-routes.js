const express = require("express");
const { check } = require("express-validator");

const adminUserControllers = require('../controllers/user-controllers');

const router = express.Router();

router.get('/user', adminUserControllers.getUsers);

router.get('/:uid/tickets', adminUserControllers.getTicketsByUserId);
// router.get('/profile/:pid', adminUserControllers.getAdminProfile);

router.post(
    '/signup',
    [
        check('name')
        .not()
        .isEmpty(),
        
        check('email')
        .normalizeEmail()
        .isEmail(),

        check('password')
        .isLength({min: 5}), 

        check('role')
        .not()
        .isEmpty(),
    ],
    adminUserControllers.signup
);

router.post('/login', adminUserControllers.login);

module.exports = router;