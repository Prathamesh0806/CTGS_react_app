const express = require("express");
const { check } = require("express-validator");

const ticketsControllers = require('../controllers/tickets-controllers');

const router = express.Router();

router.get('/alltickets', ticketsControllers.getAllTickets);

router.get('/resolvedtickets', ticketsControllers.getResolvedTickets);

router.get('/pendingtickets', ticketsControllers.getPendingTickets);

router.get('/:tid', ticketsControllers.getTicketsById);

router.get('/user/:uid', ticketsControllers.getTicketsByUserId);

router.post(
'/',
[
    check('issue')
    .not()
    .isEmpty(),

    check('description')
    .isLength({min: 5})
],
ticketsControllers.createTicket
 );

router.patch(
    '/:tid',
    [
        check('issue')
        .not()
        .isEmpty(),
    
        check('description')
        .isLength({min: 5})
    ],
     ticketsControllers.updateTicket);

router.delete('/:tid', ticketsControllers.deleteTicket);

module.exports = router;