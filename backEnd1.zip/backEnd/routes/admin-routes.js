const express = require("express");
const { check } = require("express-validator");

const adminControllers = require('../controllers/admin-controllers');

const router = express.Router();


router.get('/', adminControllers.getUsers);

router.get('/profile/:pid', adminControllers.getAdminProfile);

router.post(
    '/signup',
    [
        check('name')
        .not()
        .isEmpty(),
        
        check('email')
        .normalizeEmail()
        .isEmail(),

        check('password')
        .isLength({min: 5}), 

        check('role')
        .not()
        .isEmpty(),
    ],
     adminControllers.signup
);

router.post('/login', adminControllers.login);

module.exports = router;