const { validationResult } = require("express-validator");
const mongoose = require('mongoose');

const HttpError = require("../models/http-error");
const Ticket = require("../models/tickets");
const User = require("../models/users");
const AdminUser = require('../models/adminUser');



const getAllTickets = async (req, res, next) => {

    let ticket;
    try {
         ticket = await Ticket.find();
    } catch (err) {
        const error = new HttpError(
            'Somthing went wrong find a ticket', 500
        );
        return next(error); 
    }
 
    if(!ticket) {
        const error =  new HttpError('Could not find a ticket', 404);
        return next(error);
    }
 
    res.json({tickets: ticket.map(ticket => ticket.toObject({getters:true}))});
};

const getResolvedTickets = async (req, res, next) => {
    

    let tickets;
    try {
        tickets = await Ticket.find({status:"Resolved"});
    } catch(err) {
        const error = new HttpError('Fetching tickets failed, please try again', 500);
        return next(error);
    }
   

    if(!tickets || tickets.length === 0) {
       return next(new HttpError('Could not find a ticket', 404)); 
    }
 
    res.json({tickets: tickets.map(ticket => ticket.toObject({getters:true}))});
}

const getPendingTickets = async (req, res, next) => {
    

    let tickets;
    try {
        tickets = await Ticket.find({status:"Pending"});
    } catch(err) {
        const error = new HttpError('Fetching tickets failed, please try again', 500);
        return next(error);
    }
   

    if(!tickets || tickets.length === 0) {
       return next(new HttpError('Could not find a ticket', 404)); 
    }
 
    res.json({tickets: tickets.map(ticket => ticket.toObject({getters:true}))});
}

const getTicketsById = async (req, res, next) => {
    const ticketId = req.params.tid;

    let ticket;
    try {
         ticket = await Ticket.findById(ticketId);
    } catch (err) {
        const error = new HttpError(
            'Somthing wen wrong find a ticket', 500
        );
        return next(error); 
    }
 
    if(!ticket) {
        const error =  new HttpError('Could not find a ticket', 404);
        return next(error);
    }
 
    res.json({ticket: ticket.toObject({ getters: true})});
};

const getTicketsByUserId = async (req, res, next) => {
    const userID = req.params.uid;

    let tickets;
    try {
        tickets = await Ticket.find({ creator: userID});
    } catch(err) {
        const error = new HttpError('Fetching tickets failed, please try again', 500);
        return next(error);
    }
   

    if(!tickets || tickets.length === 0) {
       return next(new HttpError('Could not find a ticket', 404)); 
    }
 
    res.json({tickets: tickets.map(ticket => ticket.toObject({getters:true}))});
}



const createTicket = async (req, res, next) => {
    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        console.log(errors);
        return next(new HttpError('Invalid inputs passed, please check your data.', 422));
    }

    const { issue, description, creator, admUser } = req.body;

    console.log(admUser);

    let adUser;
    try {
        adUser = await AdminUser.find({name:admUser}); 
    } catch (err) {
       const error = new HttpError(
           'Creating ticket failed, please try again-112', 
           500
       ); 
       return next(error);
    }

    if (!adUser) {
        const error = new HttpError('Could not find user for provided name', 404);
        return next(error);
    }

     console.log(adUser);

    const [{_id}] = adUser;
    const adnUser = _id;
    console.log(adnUser);

    
    const createdTicket = new Ticket({
        issue,
        description,
        status:'Submitted',
        creator,
        adnUser
    });

       
    let user;
    try {
       user = await User.findById(creator); 
    } catch (err) {
       const error = new HttpError(
           'Creating ticket failed, please try again-111', 
           500
       ); 
       return next(error);
    }

    if (!user) {
        const error = new HttpError('Could not find user for provided id', 404);
        return next(error);
    }

     console.log(user);

    let rsolveUser;
    try {
        rsolveUser = await AdminUser.findById(adnUser); 
    } catch (err) {
       const error = new HttpError(
           'Creating ticket failed, please try again-112', 
           500
       ); 
       return next(error);
    }

    if (!rsolveUser) {
        const error = new HttpError('Could not find user for provided name', 404);
        return next(error);
    }

    console.log(rsolveUser);


   try {
        await createdTicket.save();
   } catch (err) {
        const error = new HttpError(
            'Creating ticket failed, please try again prathamesh.',
            500   
        );
    return next(error);
   }

   user.tickets.push(createdTicket);
   rsolveUser.tickets.push(createdTicket);

   try {
    await user.save();
   } catch (err) {
        const error = new HttpError(
            'Creating ticket failed, please try again prathamesh2.',
            500   
        );
    return next(error);
   }
//    rsolveUser.tickets.push(createdTicket);
   try {
    await rsolveUser.save();
   } catch (err) {
        const error = new HttpError(
            'Creating ticket failed, please try again prathamesh3.',
            500   
        );
    return next(error);
   }

    res.status(201).json({ticket:createdTicket});
}

const  updateTicket =async (req, res, next) => {
    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        console.log(errors);
        throw new HttpError('Invalid inputs passed, please check your data.', 422);
    }

    const { issue, description, status} = req.body; 
    const ticketId = req.params.tid;

    let ticket;
    try {
       ticket = await Ticket.findById(ticketId); 
    } catch (err) {
       const error = new HttpError('Something went wrong, could not update ticketsss.', 500);
       return next(error); 
    }

    ticket.issue =issue; 
    ticket.description = description;
    ticket.status= status || 'Submitted';

    console.log(ticket);

    try {
        await ticket.save();
    } catch (err) {
        const error = new HttpError('Something went wrong, could not update ticket33.', 500);
        return next(error);  
    }

    res.status(200).json({ticket: ticket.toObject({ getters: true})});  
}

const deleteTicket = async (req, res, next) => {
    const ticketId = req.params.tid;
    

    let ticket;
    try {
        ticket = await Ticket.findById(ticketId).populate('creator');
    } catch (err) {
        const error = new HttpError('Something went wrong, could not delete ticket.', 500);
        return next(error); 
    }

    if (!ticket) {
        const error = new HttpError('Could not find a ticket for this id.', 404);
        return next(error);
    }

    try {
        await ticket.remove();
    } catch (err) {
        const error = new HttpError('Something went wrong, could not delete ticket-1.', 500);
        return next(error);   
    }

    ticket.creator.tickets.pull(ticket);
    try {
        await ticket.creator.save();
    } catch (err) {
        const error = new HttpError('Something went wrong, could not delete ticket-2.', 500);
        return next(error);   
    }

    res.status(200).json({message:"Delete ticket successfully!"})
}

exports.getAllTickets = getAllTickets;
exports.getResolvedTickets = getResolvedTickets;
exports.getPendingTickets = getPendingTickets;
exports.getTicketsById = getTicketsById;
exports.getTicketsByUserId = getTicketsByUserId;
exports.createTicket = createTicket;
exports.updateTicket = updateTicket;
exports.deleteTicket = deleteTicket;
