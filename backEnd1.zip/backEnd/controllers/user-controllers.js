const HttpError = require('../models/http-error');
const { validationResult } = require("express-validator");

const AdminUser = require('../models/adminUser');
const Ticket = require('../models/tickets')


const getUsers = async (req, res, next) => {
    // res.json({users: DUMMY_USERS});

    let users ;
   try {
     users = await AdminUser.find({}, '-password');
   } catch (err) {
       const error = new HttpError('Fetching users failed, please try again later.', 500);
        return next(error);
   }
   res.json({users: users.map(user => user.toObject({getters:true}))});
}

const getTicketsByUserId = async (req, res, next) => {
    const userID = req.params.uid;
    console.log(userID);
    let tickets;
    try {
        tickets = await Ticket.find({ adnUser: userID});
    } catch(err) {
        const error = new HttpError('Fetching tickets failed, please try again', 500);
        return next(error);
    }
   

    if(!tickets || tickets.length === 0) {
       return next(new HttpError('Could not find a ticket', 404)); 
    }
 
    res.json({tickets: tickets.map(ticket => ticket.toObject({getters:true}))});
}


const signup = async (req, res, next) => {
    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        console.log(errors);
        return next( new HttpError('Invalid inputs passed, please check your data.', 422));
    }

    const { name, email, password, role} = req.body;

    let existingUser;
    try{
        existingUser = await AdminUser.findOne({email: email})
    } catch(err) {
        const error = new HttpError('Signing up failed, please try again later.', 500);
        return next(error);
    }

    if(existingUser) {
        const error = new HttpError('User exist alredy, please login instead.', 422);
        return next(error);
    }

    // const hasUser = DUMMY_USERS.find(u => u.email === email);
    // if (hasUser) {
    //     throw new HttpError('Could not create user, email already exists.', 422);
    // }
    
    const createAdminUser = new AdminUser({
        name,
        email, 
        password,
        role,
        tickets:[]
    });

    try {
        await createAdminUser.save();
    } catch (err) {
        const error = new HttpError('Creating user failed, please try again.',500);
        return next(error);
    }
    // DUMMY_USERS.push(createUser);

    res.status(201).json({users: createAdminUser.toObject({getters:true})});
};

const login = async (req, res, next) => {
    const { email, password} = req.body;

    let existingUser;
    try{
        existingUser =await AdminUser.findOne({email: email})
    } catch(err) {
        const error = new HttpError('Logging in failed, please try again later.', 500);
        return next(error);
    }

    if(!existingUser || existingUser.password !== password) {
        const error = new HttpError('Invalid credentials, could not log you in.', 401);
        return next(error);
    }

    res.json({message: 'Logged in!',  userId: existingUser.id, role: existingUser.role});
}

exports.getUsers = getUsers;
exports.getTicketsByUserId = getTicketsByUserId;
exports.signup = signup;
exports.login = login;