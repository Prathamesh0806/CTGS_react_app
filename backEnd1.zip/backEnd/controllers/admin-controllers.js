const HttpError = require('../models/http-error');
const { validationResult } = require("express-validator");

const Admin = require('../models/admin');
// const users = require('../models/users');

// const DUMMY_USERS = [
//     {
//         id: 'u1',
//         name: 'John Smith',
//         email: 'john@example.com',
//         password: 'jhon@@'
//     },
//     {
//         id: 'u2',
//         name: 'Joy Deo',
//         email: 'joy@example.com',
//         password: 'joy22@@'
//     },
//     {
//         id: 'u3',
//         name: 'Alena Gilbrat',
//         email: 'alena@example.com',
//         password: 'alena@@'
//     }
// ]

const getUsers = async (req, res, next) => {
    // res.json({users: DUMMY_USERS});

    let users ;
   try {
     users = await Admin.find({}, '-password');
   } catch (err) {
       const error = new HttpError('Fetching users failed, please try again later.', 500);
        return next(error);
   }
   res.json({users: users.map(user => user.toObject({getters:true}))});
}

const getAdminProfile = async (req, res, next) => {
    const adminId = req.params.pid;
    console.log(adminId);

    let users ;
   try {
     users = await Admin.findById(adminId);
   } catch (err) {
       const error = new HttpError('Fetching users failed, please try again later.', 500);
        return next(error);
   }
   res.json({name: users.name, email: users.email, role: users.role});
//    res.json({ticket: ticket.toObject({ getters: true})});
}

const signup = async (req, res, next) => {
    const errors = validationResult(req);

    if(!errors.isEmpty()) {
        console.log(errors);
        return next( new HttpError('Invalid inputs passed, please check your data.', 422));
    }

    const { name, email, password, role} = req.body;

    let existingUser;
    try{
        existingUser = await Admin.findOne({email: email})
    } catch(err) {
        const error = new HttpError('Signing up failed, please try again later.', 500);
        return next(error);
    }

    if(existingUser) {
        const error = new HttpError('User exist alredy, please login instead.', 422);
        return next(error);
    }

    // const hasUser = DUMMY_USERS.find(u => u.email === email);
    // if (hasUser) {
    //     throw new HttpError('Could not create user, email already exists.', 422);
    // }
    
    const createAdmin = new Admin({
        name,
        email, 
        password,
        role
    });

    try {
        await createAdmin.save();
    } catch (err) {
        const error = new HttpError('Creating user failed, please try again.',500);
        return next(error);
    }
    // DUMMY_USERS.push(createUser);

    res.status(201).json({users: createAdmin.toObject({getters:true})});
};

const login = async (req, res, next) => {
    const { email, password} = req.body;

    let existingUser;
    try{
        existingUser =await Admin.findOne({email: email})
    } catch(err) {
        const error = new HttpError('Logging in failed, please try again later.', 500);
        return next(error);
    }

    if(!existingUser || existingUser.password !== password) {
        const error = new HttpError('Invalid credentials, could not log you in.', 401);
        return next(error);
    }

    res.json({message: 'Logged in!',  userId: existingUser.id, role: existingUser.role});
}

exports.getUsers = getUsers;
exports.getAdminProfile = getAdminProfile;
exports.signup = signup;
exports.login = login;