const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const ticketsRoutes = require('./routes/tickets-routes');
const usersRoutes = require('./routes/users-routes');
const adminRoutes = require('./routes/admin-routes');
const adminUsersRoutes = require('./routes/user-routes')

const app = express();

app.use(bodyParser.json());

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    next();
})

app.use('/api/tickets', ticketsRoutes);

app.use('/api/users', usersRoutes);

app.use('/api/admin', adminRoutes);

app.use('/api/adminUser', adminUsersRoutes);

app.use((req, res, next) => {
    const error = new HttpError("Could not connect with that path!",404);
    throw error;
});
  
app.use((error, req, res, next) => {
    if (res.headerSent) {
      return next(error);
    } 
    res.status(error.code || 500)
    res.json({message: error.message || 'An unknown error occurred!'});
});
  

mongoose
// .connect('mongodb://localhost:27017/mernDB', {useNewUrlParser: true})
.connect(
    `mongodb+srv://prathamesh:Pr9345@ctgssystem.sc84bcx.mongodb.net/?retryWrites=true&w=majority`
)
.then(() => {
    app.listen(5000);
})
.catch(err => {
    console.log(err);
});

console.log(typeof(typeof(1)));