import React from 'react';

import './Logo.css';

const Logo = props => {
  return (
    <div className="image-container">
        <img className={`logo-${props.className} && logo`}
        src={props.image}
        alt={props.alt}
        style={{ width: props.width, height: props.width }}
      />
    </div>
  );
};

export default Logo;