import React from 'react';

import Card from '../../shared/components/UIElements/Card';
import TicketItem from '../../tickets/components/TicketItem';
import Button from '../../shared/components/FormElements/Button';
import './TicketList.css';

const TicketList = props => {
    if (props.items.length === 0) {
        return (
            <div className="ticket-list center">
                <Card>
                    <h2>No tickets found. May be create one?</h2>
                    <Button to={`/tickets/new`}>Add Ticket</Button>
                </Card>
            </div>
        );
    }

    return <ul className="ticket-list">
        {props.items.map(ticket => 
            <TicketItem 
                key={ticket.id} 
                id={ticket.id} 
                issue={ticket.issue} 
                description={ticket.description} 
                creatorId={ticket.creatorId}
                status={ticket.status}
                onDelete={props.onDelete}
            />
        )}
    </ul>
};

export default TicketList;