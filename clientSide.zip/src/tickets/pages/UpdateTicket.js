import React, { useEffect, useState, useContext } from 'react';
import { useParams, useHistory} from 'react-router-dom';

import Input from '../../shared/components/FormElements/Input';
import Button from '../../shared/components/FormElements/Button';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import Card from '../../shared/components/UIElements/Card';
import {useForm} from '../../shared/hooks/form-hook';
import { VALIDATOR_MINLENGTH, VALIDATOR_REQUIRE } from '../../shared/util/validators';
import {useHttpClient} from '../../shared/hooks/http-hook';
import { AuthContext } from '../../shared/context/auth-context';
import './UpdateTicket.css';


const UpdateTicket = props => {
    const auth = useContext(AuthContext);
    const [loadedTickets, setLoadedTickets] = useState();
    const {isLoading, error, sendRequest, clearError} = useHttpClient();
    const ticketId = useParams().ticketId;
    const history = useHistory();

    const [formState, inputHandler, setFormData] = useForm(
        {
          issue: {
            value: '',
            isValid: false
          },
          description: {
            value: '',
            isValid: false
          }
        },
        false
    );

    // const identifyTicket = DUMMY_TICKETS.find(t => t.id === ticketId);
    useEffect(() => {
        const fetchTicket =async () => {
          try {
            const responseData = await sendRequest(`http://localhost:5000/api/tickets/${ticketId}` 
            );
            console.log(responseData.ticket);
            setLoadedTickets(responseData.ticket);
            setFormData(
                {
                issue: {
                    value: responseData.ticket.issue,
                    isValid: true
                },
                description: {
                    value: responseData.ticket.description,
                    isValid: true
                }
                },
                true
            );
          } catch (err) {
              
          }
        };
    
        fetchTicket();
        }, [sendRequest, ticketId, setFormData]);

    console.log();
   
    const ticketSubmitHandler = async event => {
        event.preventDefault();
        console.log(formState);
        try {
            await sendRequest(`http://localhost:5000/api/tickets/${ticketId}`,
                'PATCH',
                JSON.stringify({
                    issue: formState.inputs.issue.value,
                    description: formState.inputs.description.value
                }),
                {
                    'Content-Type': 'application/json'
                }
            );
            history.push(`/${auth.userId}/tickets`);
        } catch (err) {
            
        }
    };

    if (isLoading) {
        return (
          <div className="center">
            <h1><LoadingSpinner /></h1>
          </div>
        );
    }

    if (!loadedTickets && !error) {
      return  <div className="center main">
        <Card >
          <h3>Could not found ticket</h3>
        </Card>
      </div>;
    }
    
  return (
    <div>
    <ErrorModal error={error} onClear={clearError}/>

       { !isLoading && loadedTickets && <form className="place-form" onSubmit={ticketSubmitHandler}>
            <Input
                id="issue"
                element="input"
                type="text"
                label="Issue"
                validators={[VALIDATOR_REQUIRE()]}
                errorText="Please enter a valid issue."
                onInput={inputHandler}
                initialValue={ loadedTickets.issue }
                initialValid={ true}
            />
            <Input
                id="description"
                element="textarea"
                label="Description"
                validators={[VALIDATOR_MINLENGTH(5)]}
                errorText="Please enter a valid description at lest 5 characters."
                onInput={inputHandler}
                initialValue={ loadedTickets.description }
                initialValid={ true}
            />
            <Button type="submit" disabled={!formState.isValid}>UPDATE TICKET</Button>
        </form>}
    </div>
  );
}

export default UpdateTicket;