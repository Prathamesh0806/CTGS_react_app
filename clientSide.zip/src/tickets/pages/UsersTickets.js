import React, { useState, useEffect} from 'react';
import { useParams } from 'react-router-dom';

import TicketList from '../components/TicketList';
import ErrorModal from '../../shared/components/UIElements/ErrorModal';
import LoadingSpinner from '../../shared/components/UIElements/LoadingSpinner';
import { useHttpClient } from '../../shared/hooks/http-hook';

// const DUMMY_TICKETS = [
//     {
//         id: 't1',
//         issue: 'Light Off',
//         description: 'In my lab suddenly lights is off. I try to find out the reasone I got the reasone durring the overloading of lights circuit goes broken.',
//         creatorId: 'u1'
//     },
//     {
//         id: 't2',
//         issue: 'Light Off',
//         description: 'In my lab suddenly lights is off. I try to find out the reasone I got the reasone durring the overloading of lights circuit goes broken.',
//         creatorId: 'u1'
//     },
//     {
//         id: 't3',
//         issue: 'Light Off',
//         description: 'In my lab suddenly lights is off. I try to find out the reasone I got the reasone durring the overloading of lights circuit goes broken.',
//         creatorId: 'u3'
//     }
// ];

const UsersTickets = () => {
    const [loadedTickets, setLoadedTickets] = useState();
    const {isLoading, error, sendRequest, clearError} = useHttpClient();

    const userId = useParams().userId;

    useEffect(() => {
    const fetchTickets =async () => {
      try {
        const responseData = await sendRequest(`http://localhost:5000/api/tickets/user/${userId}` 
        );
        setLoadedTickets(responseData.tickets);
      } catch (err) {
          
      }
    };

    fetchTickets();
    }, [sendRequest, userId]);

    const ticketDeletedHandeler = (deletedTicket) => {
      setLoadedTickets(prevTickets =>prevTickets.filter(ticket => ticket.id !== deletedTicket));
    }

   
  return (
  <React.Fragment>
  <ErrorModal error={error} onClear={clearError}/>
  {isLoading && (<div className="center">
    <LoadingSpinner />
  </div>)}
    {!isLoading && loadedTickets && <TicketList items={loadedTickets} onDelete={ticketDeletedHandeler} />}
  </React.Fragment>
  );
};

export default UsersTickets;